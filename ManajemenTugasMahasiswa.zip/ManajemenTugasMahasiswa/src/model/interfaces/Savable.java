package model.interfaces;

public interface Savable {
    boolean saveToDB();
}